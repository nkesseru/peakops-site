PeakOps Regulatory Packet (V1)

orgId: org_001
incidentId: inc_pn6pbhe7
purpose: REGULATORY
generatedAt: 2025-12-30T15:13:25.505Z
packetHash: 36ed501516e1ac712238bc65b96f5b0ae84609d949e8827924feced42fe4da25

How to use:
1) This ZIP is deterministic: all JSON is stable-sorted and hashed.
2) Verify integrity:
   - Compare packet_hash.txt to manifest.json hash map.
   - Each file hash in manifest.json should match sha256(file contents).
3) Primary artifacts:
   - incident/incident.json
   - filings/filings.json
   - timeline/timeline_events.json
   - evidence/evidence_locker.json
