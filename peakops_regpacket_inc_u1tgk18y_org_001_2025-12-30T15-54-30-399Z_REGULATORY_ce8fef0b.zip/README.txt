PeakOps Regulatory Packet (V1)

orgId: org_001
incidentId: inc_u1tgk18y
purpose: REGULATORY
generatedAt: 2025-12-30T15:54:30.399Z
packetHash: ce8fef0bab304d1ef08a530a8ea7fcf683067ec8f915bcc66e00c2420a2f6f2c

How to use:
1) This ZIP is deterministic: all JSON is stable-sorted and hashed.
2) Verify integrity:
   - Compare packet_hash.txt to manifest.json hash map.
   - Each file hash in manifest.json should match sha256(file contents).
3) Primary artifacts:
   - incident/incident.json
   - filings/filings.json
   - timeline/timeline_events.json
   - evidence/evidence_locker.json
