PeakOps Regulatory Packet (V1)

orgId: org_001
incidentId: inc_v14vjk1i
purpose: REGULATORY
generatedAt: 2025-12-30T15:54:37.480Z
packetHash: d090ac0dcf885d234bd00aad912f3110e07d7e8db84189718bef1f947bff0a05

How to use:
1) This ZIP is deterministic: all JSON is stable-sorted and hashed.
2) Verify integrity:
   - Compare packet_hash.txt to manifest.json hash map.
   - Each file hash in manifest.json should match sha256(file contents).
3) Primary artifacts:
   - incident/incident.json
   - filings/filings.json
   - timeline/timeline_events.json
   - evidence/evidence_locker.json
